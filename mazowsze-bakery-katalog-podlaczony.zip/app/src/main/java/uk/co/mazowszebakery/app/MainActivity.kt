package uk.co.mazowszebakery.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Ink = Color(0xFF171512)
private val Gold = Color(0xFFC6A15B)
private val Cream = Color(0xFFF7F3EA)

data class BakeryProduct(val category: String, val name: String, val unit: String, val price: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val catalog = loadProducts()
        setContent { BakeryApp(catalog) }
    }

    private fun loadProducts(): List<BakeryProduct> {
        val raw = assets.open("products.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val array = JSONArray(raw)
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            BakeryProduct(item.getString("category"), item.getString("name"),
                item.getString("unit"), item.getDouble("price"))
        }
    }
}

@Composable
fun BakeryApp(products: List<BakeryProduct>) {
    val quantities = remember { mutableStateMapOf<String, Int>() }
    var tab by remember { mutableStateOf("Zamówienie") }
    var category by remember { mutableStateOf("Wszystkie") }
    val categories = listOf("Wszystkie") + products.map { it.category }.distinct()
    val shown = products.filter { category == "Wszystkie" || it.category == category }
    val total = products.sumOf { it.price * (quantities[it.name] ?: 0) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Ink, secondary = Gold, background = Cream)) {
        Scaffold(containerColor = Cream, bottomBar = {
            NavigationBar(containerColor = Ink) {
                listOf("Zamówienie", "Historia", "Konto").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {},
                        label = { Text(item, color = if (tab == item) Gold else Color.White) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("MAZOWSZE", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("BAKERY  •  ZAMÓWIENIA", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    "Zamówienie" -> {
                        Text("Dzisiejsze zamówienie", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("Ceny brutto • GBP (£) • ${products.size} produktów", color = Color.Gray, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories) { item ->
                                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
                            }
                        }
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(shown) { product ->
                                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(product.name, fontWeight = FontWeight.SemiBold, color = Ink)
                                            Text("£%.2f / %s".format(product.price, product.unit), color = Color.Gray, fontSize = 12.sp)
                                            Text(product.category, color = Gold, fontSize = 10.sp)
                                        }
                                        IconButton(onClick = { quantities[product.name] = maxOf(0, (quantities[product.name] ?: 0) - 1) }) { Text("−", fontSize = 22.sp) }
                                        Text((quantities[product.name] ?: 0).toString(), fontWeight = FontWeight.Bold)
                                        IconButton(onClick = { quantities[product.name] = (quantities[product.name] ?: 0) + 1 }) { Text("+", fontSize = 22.sp) }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text("Wartość zamówienia", color = Color.LightGray)
                                Text("£%.2f".format(total), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = { }, enabled = quantities.values.any { it > 0 },
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold), modifier = Modifier.fillMaxWidth()) {
                                    Text("Zapisz zamówienie", color = Ink, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    "Historia" -> Text("Historia zamówień będzie dostępna po podłączeniu wspólnej bazy danych.", color = Ink)
                    else -> Text("Konto pracownika\n\nLogowanie i panel administratora wymagają jeszcze podłączenia serwera.", color = Ink)
                }
            }
        }
    }
}
